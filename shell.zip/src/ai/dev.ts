import { config } from 'dotenv';
config();

import '@/ai/flows/conflict-flagging.ts';